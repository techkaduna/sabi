Sabi - Translate plain English to Naija pidgin.
===============================================

A simple module to translate plain English to Nigerian (Naija) pidgin English.

I encountered arrr.py while doing some Python study and had been planning to write 
a python module as my final year project before then so, what a way to start. It is 
also important to mention that I drew lots of inspiration from arrr.py module.

There is the pidginUNMT project, which is more than capable for the job but then - 
there's numpy and there's pandas.

Installation
------------

To install ::

    $ pip install arrr

Command-line Usage
------------

Command-line Usage::
    $ sabi --oyinbo "how are you"

    $ sabi --long-tok filename.txt


Contibution
------------

The source code is  `hosted in GitHub <https://github.com/techkaduna/sabi>`_. Please
feel free to fork the repository and contribute. I already appreciate it.
